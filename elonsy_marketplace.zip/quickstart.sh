#!/bin/bash
echo "Quick start for Elonsy Marketplace (development)"
echo "1) Start MongoDB (or use docker-compose)"
echo "2) cd server && npm install && cp .env.example .env && edit .env"
echo "3) cd client && npm install"
echo "4) Run server: cd server && npm run dev"
echo "5) Run client: cd client && npm run dev"
