Client: cd client && npm install && npm run dev
