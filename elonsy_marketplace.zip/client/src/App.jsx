import React, { useEffect, useState } from 'react'

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000'

export default function App() {
  const [products, setProducts] = useState([])
  const [q, setQ] = useState('')

  useEffect(() => {
    fetch(API + '/api/products')
      .then(res => res.json())
      .then(setProducts)
      .catch(err => console.error('API error', err))
  }, [])

  const filtered = products.filter(p => p.title.toLowerCase().includes(q.toLowerCase()) || p.description.toLowerCase().includes(q.toLowerCase()))

  return (
    <div className="max-w-6xl mx-auto p-6">
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Elonsy Training Shop</h1>
        <input value={q} onChange={e => setQ(e.target.value)} placeholder="Search products" className="border p-2 rounded" />
      </header>

      <main>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map(p => (
            <div key={p._id} className="bg-white p-4 rounded shadow">
              <img src={p.image || 'https://placehold.co/600x400?text=Product'} alt={p.title} className="h-40 w-full object-cover rounded" />
              <h3 className="font-semibold mt-2">{p.title}</h3>
              <div className="text-sm text-gray-600">K {p.price}</div>
              <p className="text-sm mt-2">{p.description}</p>
            </div>
          ))}
        </div>
      </main>
    </div>
  )
}
