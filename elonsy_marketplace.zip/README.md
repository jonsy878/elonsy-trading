Elonsy Training Shop — Full-stack starter (React + Express)

What you get:
- Frontend: Vite + React + Tailwind single-page marketplace (src/)
- Backend: Express + MongoDB-ready REST API with auth (bcrypt + JWT)
- Dockerfile and docker-compose for local development
- .env.example for environment variables
- Scripts to run frontend and backend
- Instructions for deploying to Google Cloud Run and uploading the zip to Google Drive

IMPORTANT:
- This is a starter template. Replace placeholder secrets and connect to a real database (MongoDB Atlas or a local MongoDB).
- Stripe / payment integration is included as a placeholder. You need to add your Stripe keys and confirm webhooks in production.

Folder structure:
- client/        (React app)
- server/        (Express API)
- docker-compose.yml
- Dockerfile      (for server)
- README.md

Next steps (examples):
1. Extract the zip.
2. Edit server/.env with your values.
3. Run `docker-compose up --build` (requires Docker) or run client and server separately:
   - cd server && npm install && npm run dev
   - cd client && npm install && npm run dev

