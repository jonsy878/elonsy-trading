const express = require('express');
const router = express.Router();
const Order = require('../models/Order');

// Create order
router.post('/', async (req, res) => {
  try {
    const { buyerId, items, amount } = req.body;
    const order = new Order({ buyer: buyerId, items, amount, status: 'pending' });
    await order.save();
    res.json(order);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// List orders (admin / user)
router.get('/', async (req, res) => {
  const orders = await Order.find().populate('buyer','name email').populate('items.product');
  res.json(orders);
});

module.exports = router;
