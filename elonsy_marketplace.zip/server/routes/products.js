const express = require('express');
const router = express.Router();
const Product = require('../models/Product');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });
const jwt = require('jsonwebtoken');
const User = require('../models/User');

// Public: list products
router.get('/', async (req, res) => {
  const q = req.query.q || '';
  const category = req.query.category;
  const filter = {};
  if (q) filter.$or = [{ title: new RegExp(q,'i') }, { description: new RegExp(q,'i') }];
  if (category) filter.category = category;
  const products = await Product.find(filter).populate('seller','name email');
  res.json(products);
});

// Create product (seller)
router.post('/', upload.single('image'), async (req, res) => {
  try {
    // NOTE: This demo does not verify JWT in file to keep template small. Add middleware in production.
    const { title, description, price, category, stock, sellerId } = req.body;
    const image = req.file ? '/uploads/' + req.file.filename : req.body.image;
    const p = new Product({ title, description, price, category, stock, image, seller: sellerId });
    await p.save();
    res.json(p);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Get single
router.get('/:id', async (req, res) => {
  const p = await Product.findById(req.params.id).populate('seller','name email');
  if (!p) return res.status(404).json({ message: 'Not found' });
  res.json(p);
});

// Simple update
router.put('/:id', async (req, res) => {
  const updated = await Product.findByIdAndUpdate(req.params.id, req.body, { new: true });
  res.json(updated);
});

// Delete
router.delete('/:id', async (req, res) => {
  await Product.findByIdAndDelete(req.params.id);
  res.json({ message: 'Deleted' });
});

module.exports = router;
