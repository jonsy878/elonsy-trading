Server: cd server && npm install && cp .env.example .env && edit .env && npm run dev
